<?php
//for more info fb.com/ijsamp
?>  <div class="panel-footer" style="text-align:center; margin-top:310px">
        		Powered by <a href="http://www.sourcecodester.com/user/ijsamp/track?deXacApps=dexConnect" target="_blank">Open SourceCode</a> | <a href="https://www.facebook.com/ROYALISTAS.WEEBLY.C0M?www.jihadQuery.com" target="_blank">Contact </a>| <a href="https://www.facebook.com/JAseveretricks?www.jihadQuery.com" target="_blank">Like Us </a><br>
				GNU General Public License, (<a href="gnu-license.php?track=#">GPL Free Software</a>)
   </div>