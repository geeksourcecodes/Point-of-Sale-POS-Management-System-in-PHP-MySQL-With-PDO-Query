
<html>
	<head>
		<script>
			function hist()
			{
				window.location = "http://-/transaction.php";
			}
		</script>
		<style>
			form { padding-top: 20px; }
			body { padding: 20px; }
		</style>
	</head>
	<body>
		<?php include('pageheader.php'); ?><?php include('acwidgetclose.php'); ?>
	This program is free software: you can redistribute it and/or modify<br >
    it under the terms of the GNU General Public License as published by<br >
    the Free Software Foundation, either version 3 of the License, or<br >
    (at your option) any later version.<br ><br >

    This program is distributed in the hope that it will be useful,<br >
    but WITHOUT ANY WARRANTY; without even the implied warranty of<br >
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br >
    GNU General Public License for more details.<br ><br >

    You should have received a copy of the GNU General Public License<br >
    along with this program.  If not, see <http://www.gnu.org/licenses/>.<br >
	For programs that are more than one file, it is better to replace “this program” with the name of the program, and begin the statement with a line saying “This file is part of DEX Connect)”. For instance,<br ><br >

    This file is part of DEX Connect.<br ><br >

    DEX Connect is free software: you can redistribute it and/or modify<br >
    it under the terms of the GNU General Public License as published by<br >
    the Free Software Foundation, either version 3 of the License, or<br >
    (at your option) any later version.<br ><br >

    DEX Connect is distributed in the hope that it will be useful,<br >
    but WITHOUT ANY WARRANTY; without even the implied warranty of<br >
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the<br >
    GNU General Public License for more details.<br ><br >

    You should have received a copy of the GNU General Public License<br >
    along with DEX Connect.  If not, see <http://www.gnu.org/licenses/>.<br >
        <div style="text-align:right"><?php include('footer.php'); ?>
        </div>
	</body>
</html>